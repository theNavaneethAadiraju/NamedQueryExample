package com.example;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.hibernate.cfg.Configuration;

import java.util.List;


@SuppressWarnings("deprecation")
public class EmployeeService {

    private SessionFactory sessionFactory;

    public EmployeeService() {
        // Configure Hibernate and build the SessionFactory
        sessionFactory = new Configuration().configure().buildSessionFactory();
    }

    
    public void createEmployee(String name) {
        Session session = sessionFactory.openSession();
        Transaction tx = session.beginTransaction();

        Employee emp = new Employee();
        emp.setName(name);

        session.save(emp);
        tx.commit();
        session.close();
    }

    public List<Employee> findAllEmployees() {
        Session session = sessionFactory.openSession();
        List<Employee> employees = session.createNamedQuery("Employee.findAll", Employee.class).getResultList();
        session.close();
        return employees;
    }

    public Employee findEmployeeByName(String name) {
        Session session = sessionFactory.openSession();
        Query<Employee> query = session.createNamedQuery("Employee.findByName", Employee.class);
        query.setParameter(1, name);  // Placeholder index starts from 1
        Employee employee = query.getSingleResult();
        session.close();
        return employee;
    }

    public void updateEmployee(Long id, String newName) {
        Session session = sessionFactory.openSession();
        Transaction tx = session.beginTransaction();

        Query query = session.createNamedQuery("Employee.updateNameById");
        query.setParameter(1, id);  // ID placeholder
        query.setParameter(2, newName);  // New name placeholder
        int rowsAffected = query.executeUpdate();

        tx.commit();
        session.close();
        System.out.println("Rows updated: " + rowsAffected);
    }

    public void deleteEmployee(Long id) {
        Session session = sessionFactory.openSession();
        Transaction tx = session.beginTransaction();

        Query query = session.createNamedQuery("Employee.deleteById");
        query.setParameter(1, id);  // ID placeholder
        int rowsAffected = query.executeUpdate();

        tx.commit();
        session.close();
        System.out.println("Rows deleted: " + rowsAffected);
    }

    public void close() {
        if (sessionFactory != null && !sessionFactory.isClosed()) {
            sessionFactory.close();
        }
    }
}
