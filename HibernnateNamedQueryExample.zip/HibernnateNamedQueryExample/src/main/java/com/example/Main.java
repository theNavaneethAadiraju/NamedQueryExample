package com.example;

import java.util.List;

public class Main {
    public static void main(String[] args) {
        EmployeeService service = new EmployeeService();

        // Create employees
        service.createEmployee("John Doe");
        service.createEmployee("Jane Smith");

        // Find and print all employees
        List<Employee> employees = service.findAllEmployees();
        System.out.println("All Employees:");
        for (Employee emp : employees) {
            System.out.println("ID: " + emp.getId() + ", Name: " + emp.getName());
        }

        // Find employee by name
        Employee emp = service.findEmployeeByName("Jane Smith");
        System.out.println("Found Employee: ID: " + emp.getId() + ", Name: " + emp.getName());

        // Update employee
        service.updateEmployee(emp.getId(), "Jane Doe");

        // Find and print updated employee
        emp = service.findEmployeeByName("Jane Doe");
        System.out.println("Updated Employee: ID: " + emp.getId() + ", Name: " + emp.getName());

        // Delete employee
        service.deleteEmployee(emp.getId());

        // Close the service
        service.close();
    }
}
