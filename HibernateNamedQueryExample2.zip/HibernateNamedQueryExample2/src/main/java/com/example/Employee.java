package com.example;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;

@Entity
@NamedQueries({
    @NamedQuery(name = "Employee.findById", query = "SELECT e FROM Employee e WHERE e.id = ?1"),
    @NamedQuery(name = "Employee.updateSalary", query = "UPDATE Employee e SET e.salary = ?1 WHERE e.id = ?2"),
    @NamedQuery(name = "Employee.deleteById", query = "DELETE FROM Employee e WHERE e.id = ?1")
})
public class Employee {
    @Id
    private Long id;
    private String name;
    private Double salary;

    // Getters and setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Double getSalary() {
        return salary;
    }

    public void setSalary(Double salary) {
        this.salary = salary;
    }
}
