package com.example;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Main {
    public static void main(String[] args) {
        // Create EntityManagerFactory and EntityManager
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("HibernateNamedQueryExample2");
        EntityManager em = emf.createEntityManager();

        // Create EmployeeService instance
        EmployeeService employeeService = new EmployeeService(em);

        // Example usage
        try {
            // Create a new employee
            Employee employee = new Employee();
            employee.setId(1L);
            employee.setName("John Doe");
            employee.setSalary(50000.0);

            // Persist employee
            em.getTransaction().begin();
            em.persist(employee);
            em.getTransaction().commit();

            // Retrieve employee by ID
            Employee retrievedEmployee = employeeService.getEmployeeById(1L);
            System.out.println("Retrieved Employee: " + retrievedEmployee.getName() + ", Salary: " + retrievedEmployee.getSalary());

            // Update employee salary
            employeeService.updateEmployeeSalary(1L, 60000.0);
            Employee updatedEmployee = employeeService.getEmployeeById(1L);
            System.out.println("Updated Employee Salary: " + updatedEmployee.getSalary());

            // Delete employee
            employeeService.deleteEmployeeById(1L);
            System.out.println("Employee deleted successfully.");

        } finally {
            em.close();
            emf.close();
        }
    }
}
