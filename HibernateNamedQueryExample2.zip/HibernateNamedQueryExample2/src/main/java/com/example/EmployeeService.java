package com.example;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;

public class EmployeeService {
    private final EntityManager entityManager;

    public EmployeeService(EntityManager entityManager) {
        this.entityManager = entityManager;
    }

    public Employee getEmployeeById(Long id) {
        Query query = entityManager.createNamedQuery("Employee.findById");
        query.setParameter(1, id); // Positional parameter
        return (Employee) query.getSingleResult();
    }

    public void updateEmployeeSalary(Long id, Double newSalary) {
        EntityTransaction transaction = entityManager.getTransaction();
        try {
            transaction.begin();
            Query query = entityManager.createNamedQuery("Employee.updateSalary");
            query.setParameter(1, newSalary); // Positional parameter
            query.setParameter(2, id);       // Positional parameter
            query.executeUpdate();
            transaction.commit();
        } catch (RuntimeException e) {
            if (transaction.isActive()) {
                transaction.rollback();
            }
            throw e;
        }
    }

    public void deleteEmployeeById(Long id) {
        EntityTransaction transaction = entityManager.getTransaction();
        try {
            transaction.begin();
            Query query = entityManager.createNamedQuery("Employee.deleteById");
            query.setParameter(1, id); // Positional parameter
            query.executeUpdate();
            transaction.commit();
        } catch (RuntimeException e) {
            if (transaction.isActive()) {
                transaction.rollback();
            }
            throw e;
        }
    }
}
